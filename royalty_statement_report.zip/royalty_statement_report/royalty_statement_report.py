# Copyright (c) 2013, Frappe Technologies Pvt. Ltd. and contributors
# For license information, please see license.txt

from __future__ import unicode_literals
import frappe

def execute(filters=None):
	#Author Name | Invoice # | BooK Title | Quantity | Royalty Amount
	columns, data = ["Author Name:Link/Supplier:200",
				#"Invoice:Link/Sales Invoice:150",
				"Book Title:Data:200","Quantity:int:75","Royalty Amount:Currency:150"], []
	where=""
	if filters.get("supplier"):
		where=""" and ir.supplier_royalties="{}" """.format(filters.get("supplier"))
	if filters.get("show_return"):
		if filters.get("show_return")==0:
			where="{}  and s.is_return=0 ".format(where)
	else:
		where="{}  and s.is_return=0 ".format(where)
	data = frappe.db.sql("""select ir.supplier_royalties, si.item_name, sum(si.qty), ir.royalties*sum(si.net_amount)/100
					from `tabSales Invoice Item` si join `tabItem Royalties` ir on ir.parent=si.item_code
					left join `tabSales Invoice` s on si.parent=s.name
					where s.docstatus=1 and (s.posting_date >= "{}" AND s.posting_date <= "{}")
					{}
					group by si.item_code
					""".format(filters.get("from_date"),filters.get("to_date"),where),as_list=1)
	return columns, data
